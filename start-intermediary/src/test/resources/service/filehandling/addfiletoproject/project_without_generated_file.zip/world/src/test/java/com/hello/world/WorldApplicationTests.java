package com.hello.world;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorldApplicationTests {

	@Test
	void contextLoads() {
	}

}
